class AverageMarks {
    public static void main(String[] args) {

        int[][] marks = {
            {80, 70, 90},
            {75, 85, 80},
            {90, 95, 85}
        };

        int sum = 0;
        int count = 0;

        for (int[] student : marks) {
            for (int mark : student) {
                sum = sum + mark;
                count++;
            }
        }

        double average = (double) sum / count;

        System.out.println("Average Marks = " + average);
    }
}